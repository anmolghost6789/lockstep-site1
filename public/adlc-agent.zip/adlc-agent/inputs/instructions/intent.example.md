# Intent

Cut KYC review from 3 days to same-day, with an analyst signing off every high-risk case.

Owner: Financial Crime Operations. Source: Jira epic FCO-1184.
